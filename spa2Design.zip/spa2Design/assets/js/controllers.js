angular.module('myApp.controller',[])

.controller('indexCtrl',function($scope,$location,$rootScope,$http)
{	
	console.log('indexCtrl');

	$scope.openNav=function()
	{
		console.log('openNav');
    	document.getElementById("mySidenav").style.width = "200px";
	}
	$scope.closeNav=function()
	{
		console.log('closeNav');
    	document.getElementById("mySidenav").style.width = "0px";
	}	

	$scope.logout=function()
	{
		$location.path('login');
	}
})


.controller('loginCtrl',function($scope,$location,$rootScope,$http,$localStorage,ngDialog)
{
	console.log('loginCtrl');

	$scope.login=function(id)
	{
		console.log($scope.user);	
		$localStorage.uname=$scope.user.uname;
//=====DEALER======================================
		if (id=='dealer') 
		{
			console.log(id);
			$http.post(url+'/dealerLogin',$scope.user).success(function(res)
			{
				console.log(res);
				if(res.type==true)
				{
					$localStorage.industry=res.industry;					
					$location.path('home');
	            	$.notify({
		                icon: 'pe-7s-gift',
		                message: res.msg+' '+res.industry
		            	},{type: 'info', timer: 1000 });		
				}
				else{
						$.notify({
				        	icon: 'fa fa-exclamation-triangle',
				        	message: res.msg
				        },{type: 'danger',timer: 1000});	
				}
				
			})					
		}
//=====customer======================================

		if (id=='cust') 
		{
			console.log(id);
			$http.post(url+'/custSignup',$scope.user).success(function(res)
			{
				console.log(res);
				if(res.type==true)
				{
					$localStorage.custemail=$scope.user.uname;
					$localStorage.custName=res.user;
	            	$.notify({
		                icon: 'pe-7s-gift',
		                message: res.msg+' '+res.user
		            	},{type: 'info', timer: 1000 });		
					$location.path('clientHome');	
				}
				if(res.type==false)
				{	
					$.notify({
				        	icon: 'fa fa-exclamation-triangle',
				        	message: res.msg
				    },{type: 'danger',timer: 1000});			
				}				
			})
		}		

	}	

	$scope.register=function()
	{
		console.log($scope.user);
		$http.post(url+'/dealerReg',$scope.user).success(function(res)
		{
			console.log(res);
			if(res=='registered')
			{
				setTimeout(function(){
					ngDialog.open({
						template: 'Registered successfully',
						plain: true,
						scope: $scope,
						closeByEscape: false,
						backdrop: 'static'
					});
					$location.path('/');					
				},1000);
			}
		})
	}	
})

.controller('homeCtrl',function($scope,$rootScope,LogTheData,$localStorage,$location)
{	
	
	$scope.user=$localStorage.uname;
	$scope.industry=$localStorage.industry;	
	$scope.class1='panel-info';
	$scope.class2="panel-danger";

	$scope.isActive = function (viewLocation)
	{
    	 return  viewLocation === $location.path();
	}

	LogTheData.receive($localStorage.uname,function(res)
	{//sends uname to server
		console.log(res.docs);
		$scope.clientPro=res.docs;
		console.log(res.activ);
		console.log($scope.clientPro);
		$scope.live=res.activ;
		$scope.inactive=$scope.clientPro.length-$scope.live;
		console.log($scope.live,$scope.inactive);
	});	

})

.controller('clientHomeCtrl',function($scope,$http,LogTheData,$localStorage,$location)
{	
	$scope.user=$localStorage.custName;
	$scope.id=$localStorage.custemail;
	$scope.bl=false;
	console.log($scope.id);

	$scope.isActive = function (viewLocation)
	{
    	 return  viewLocation === $location.path();
	}

	$scope.class1='panel-info';
	$scope.class2="panel-danger";

	$http.get(url+'/custProducts/'+$scope.id).success(function(res)
	{//sends uname to server
		console.log(res.docs);
		$scope.clientPro=res.docs;
		console.log(res.activ);
		console.log($scope.clientPro);
		$scope.live=res.activ;
		$scope.inactive=$scope.clientPro.length-$scope.live;
		console.log($scope.live,$scope.inactive);
	});	

	$scope.mqtt=function(id)	
	{
		console.log(id);
		$scope.id=id; $scope.topic=null;
		client.subscribe(id);
		client.on('message',function(topic,payload)
		{
			$scope.topic=topic;
			$scope.payload=String(payload);
			console.log($scope.topic,$scope.payload);
			$scope.$digest();
		})
	}
	
	$scope.access=function(val,id)
	{
		if(val==true)
		{
			console.log('Blocked '+id);
			client.publish(id, "Block");
		}
		if(val==false)
		{
			console.log('Unblocked '+id);
			client.publish(id, "Unblock");
		}
	}
	$scope.info=function(id)
	{
		console.log(id);
	}

})
.controller('mergeCtrl',function($scope,$rootScope,$http,$localStorage)
{
	console.log('mergeCtrl');
	$scope.user=$localStorage.uname;
    $scope.locks={},$scope.nodes={},$scope.localData=[];
    //$localStorage.$reset();
	$scope.localData.push($localStorage.htl);
	console.log($localStorage.uname);
	console.log($scope.localData);
	
	$scope.isActive = function (viewLocation)
	{
    	 return  viewLocation === $location.path();
	}
		
	//Get locks and nodes registered with client
	$http.post(url+'/prono',{client:$localStorage.uname}).success(function(res)
	{
		$scope.locks=res.lock;
		$scope.nodes=res.node;
	})


	$scope.merge=function()
	{
		$localStorage.htl={lock:$scope.loc.client_id,node:$scope.nod.node_id,merge:$scope.loc.client_id+'/'+$scope.nod.node_id};
		$scope.localData.push($localStorage.htl);
	}
})


/*

.controller('deviceCtrl',function($location,$scope,$rootScope,ngDialog,$http,LogTheData)
{
	$rootScope.topbar=true;		$rootScope.sidebar=true;
	$scope.types=[];            $scope.types=['BKW','BKV1','BKV2','B'];
	console.log('deviceCtrl');
	var logData=function()
	{
		console.log('in logData');
		$http.get(url+'/clientProducts').success(function(res)
		{
			$scope.clientPro=res;
			$scope.live=$scope.clientPro.activ;
			$scope.inactive=$scope.clientPro.docs.length-$scope.live;
		})
	}	
	logData();


	$scope.deviceAdd=function()
	{
		console.log('devices',$scope.pr);
		$http.post(url+'/addClientProduct',$scope.pr).success(function(res)
		{
	        console.log(res);
	        if(res=='pna')
	        {
	        	ngDialog.open({
	        		template:'<center>Sorry Product is not Registered..!!</center>',
	        		plain:true
	        	})
	        }
	        if(res=='added'){
				logData();
	        }			
		})
	}

	$scope.deviceType=function(typ)
	{
		console.log('type '+typ);
		$scope.types.push(typ);
		$scope.dialog1.close();
	}
	$scope.delete=function(ind)
	{
		console.log(ind);
		$scope.types.splice($scope.types.indexOf(ind),1);
		$scope.dialog1.close();
	}

	$scope.dialog=function()
	{	
		$scope.dialog1=ngDialog.open({
			template: '\
			<input type="text" ng-model="dtype" class="form-control"  placeholder="Enter Device Type">\
			<br>\<center>\
			<button type="button" class="ngdialog-button ngdialog-button-primary" ng-click="deviceType(dtype)">Add Type</button>\</center>\
			<button type="button" class="ngdialog-button ngdialog-button-neo" ng-click="delete(dtype)">Delete Type</button>\</center>\
			',
			plain: true,
			scope: $scope,
			closeByEscape: false,
			backdrop: 'static',
            keyboard: false
		});
	}
	$scope.rem=function(id)
	{
		console.log(id);
		$http.post(url+'/delProduct/'+id).success(function(res)
		{
			console.log(res);
		});
		logData();
	}	

	$scope.edit=function(id)
	{
		console.log(id);
		$http.post(url+'/editDevice/'+id).success(function(res)
		{
			$scope.pr=res;
			console.log(res);
		})
	}
	$scope.update=function(id)
	{
		console.log($scope.pr._id);
		$http.post(url+'/updateDevice/'+$scope.pr._id,$scope.pr).success(function(res)
		{
			console.log(res);
			logData();
		})
	}
	$scope.mergeProd=function(id)	
	{
		$scope.launched=[{pr:'SmartHotel-G'},{pr:'SmartLock-N'}];
		console.log(id);//ng-options="typ as typ.pr for typ in launched"
		var dialog2=ngDialog.open({
			template: '\
                <center>\
                <label></label>\
                <select class="form-control" style="width:250px" ng-model="product" required="required" ng-options="typ as typ.pr for typ in launched" >\
					<option value="">select a type</option>\
				</select><br> <center>\
			<button type="button" class="ngdialog-button ngdialog-button-primary" ng-click="merge(false)">Cancel</button>\</center>\
			<button type="button" class="ngdialog-button ngdialog-button-neo" ng-click="merge(product)">+ Merge New Product</button>\</center>\
			',
			plain: true,
			scope: $scope,
			closeByEscape: false,
			backdrop: 'static',
            keyboard: false
		});

		$scope.merge=function(val)
		{
			//console.log(val);
			if(val==false)
				$scope.dialog2.close();
			else
			{
				var dialog3=ngDialog.open({
					template:' <center>are you Sure?<center>\
					<button type="button" class="ngdialog-button ngdialog-button-primary" ng-click="close(0)">No</button>\</center>\
					<button type="button" class="ngdialog-button ngdialog-button-neo" ng-click="close(1)">YES</button>\</center>\
					',
					plain: true,
					scope: $scope,
					closeByEscape: false,
					backdrop: 'static',
		            keyboard: false
				})
			}
			$scope.close=function(id)
			{
				if(!id)
					dialog3.close();
				else if(id){
					console.log(val,id);
					dialog3.close();
					dialog2.close();
				}
			}
		}
	}
})
*/