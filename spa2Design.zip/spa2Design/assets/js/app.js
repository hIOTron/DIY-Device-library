var url='http://52.66.59.180:4001';
angular.module('myApp',['myApp.controller','oitozero.ngSweetAlert','myApp.services','ngRoute','ngDialog','angular.filter','ngStorage'])
.config(function($routeProvider)
{
	console.log('in config');

	$routeProvider
	.when('/',{
		templateUrl:'templates/login.html',
		controller:'loginCtrl',
	})

	.when('/register',{
		templateUrl:'register.html',
		controller:'loginCtrl',
	})

	.when('/home',{
		templateUrl:'dashboard.html',
		controller:'homeCtrl'
	})

	.when('/live',{
		templateUrl:'live.html',
		controller:'homeCtrl'
	})	
	.when('/inactive',{
		templateUrl:'inactive.html',
		controller:'homeCtrl'
	})	
	
	.when('/device',{
		templateUrl:'templates/device.html',
		controller:'deviceCtrl'
	})

	.when('/merge',{
		templateUrl:'merge.html',
		controller:'mergeCtrl'
	})

	.when('/clientHome',{
		templateUrl:'templates/clientHome.html',
		controller:'clientHomeCtrl'
	})

	.when('/clientLive',{
		templateUrl:'templates/clientLive.html',
		controller:'clientHomeCtrl'
	})

	.when('/clientInactive',{
		templateUrl:'templates/clientInactive.html',
		controller:'clientHomeCtrl'
	})
	.when('/list',{
		templateUrl:'templates/allist.html',
		controller:'clientHomeCtrl'
	})
	.otherwise({redirectTo: '/'});
})
