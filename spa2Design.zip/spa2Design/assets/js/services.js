var client = mqtt.connect('ws://54.238.179.124:9001')
client.on('connect',function()
{
    console.log('connected to mqtt!');
});

angular.module('myApp.services',[])

.factory('LogTheData', function($http,$localStorage) 
{
  return {
    receive: function(id,success,error) 
    {
        console.log('In receive '+id);
		$http.get(url+'/clientProducts/'+id).success(success).error(error);
    },
    send:function(data,success,error)
    {
        console.log('In send',data);    	
    	$http.post(url+'/addClientProduct',data).success(success).error(error);
    }
  }
})
