Contents in Device.zip file:

1) hIOTron.zip :- 

Open Arduino and go to sketch option. Select 'include library' and opt for 'Add .zip library' option and browse for the file to select it.

					OR

	Extract this file in C:\Users\%USERPROFILE%\Documents\Arduino\libraries
   	Here replace %USERPROFILE% by the name of the user.
					
				

2) run.exe :- 

				Just run the exe file.

					OR 

If the given path [C:\Program Files (x86)\Arduino\libraries] of run.exe file doesn't match to your arduino IDE library directory while executing or if it is in some other directory than C so kindly do it manually.
 