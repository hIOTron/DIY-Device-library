#ifndef hIOTron_h
#define hIOTron_h
#include <avr/io.h>
#include <util/delay.h>
#include <Arduino.h>
#include <SPI.h>
#include <Ethernet.h>
#include <hIOTron_MQTT.h>



void pinset();
void communication();
void infinite();
void Subscribe();
void Publish();
void ServerConnect();
void give0(const char* msd);
void give1(const char* msd);
void give2(const char* msd);
void give3(const char* msd);
void give4(const char* msd);
void give5(const char* msd);
void give6(const char* msd);
void give7(const char* msd);
void give8(const char* msd);
void give9(const char* msd);
void give10(const char* msd);
void give11(const char* msd);
void give12(const char* msd);
void give13(const char* msd);
void give14(const char* msd);
void give15(const char* msd);
void give16(const char* msd);
void give17(const char* msd);
void give18(const char* msd);
void give19(const char* msd);

#endif