#include "communication.h"
#include <ESP8266WiFi.h>
//#include <PubSubClient.h>
//#include <WiFiClientSecure.h>


void pinset1()
{
 
  pinMode(4, OUTPUT);
  pinMode(5, OUTPUT);
  pinMode(16,OUTPUT);
  pinMode(0, OUTPUT);
  pinMode(2, OUTPUT);
  pinMode(14, OUTPUT);
  pinMode(12, OUTPUT);
  pinMode(13, OUTPUT);
  pinMode(15, OUTPUT);
  pinMode(3, OUTPUT);
 // pinMode(1, OUTPUT);

  Serial.print("GPIO initilization "); 
}
