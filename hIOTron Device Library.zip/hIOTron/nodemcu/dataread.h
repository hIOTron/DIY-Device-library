#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include <WiFiClientSecure.h>

#ifndef data_h
#define data_h

void datar();


#endif


