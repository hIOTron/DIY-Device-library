

#include <ESP8266WiFi.h>
#include <PubSubClient.h>
//#include <WiFiClientSecure.h>




void callback(char* topic, byte* payload, unsigned int length)
{
  char* json;
  int i;
  json = (char*) malloc(length + 1);
  memcpy(json, payload, length);
  json[length] = '\0';
  
  if(String(json) == "D01")
    {
     digitalWrite(16, HIGH);
    }
    if(String(json) == "D00")
    {
     digitalWrite(16, LOW);
    }
    
    if(String(json) == "D11")
    {
     digitalWrite(5, HIGH);
    }
    if(String(json) == "D10")
    {
     digitalWrite(5, LOW);
    }

    if(String(json) == "D21")
    {
     digitalWrite(4, HIGH);
    }
    if(String(json) == "D20")
    {
     digitalWrite(4, LOW);
    }

    
    if(String(json) == "D31")
    {
     digitalWrite(0, HIGH);
    }
    if(String(json) == "D30")
    {
     digitalWrite(0, LOW);
    }
    
    if(String(json) == "D41")
    {
     digitalWrite(2, HIGH);
    }
    if(String(json) == "D40")
    {
     digitalWrite(2, LOW);
    }

    
    if(String(json) == "D51")
    {
     digitalWrite(14, HIGH);
    }
    if(String(json) == "D50")
    {
     digitalWrite(14, LOW);
    }

    if(String(json) == "D61")
    {
     digitalWrite(12, HIGH);
    }
    if(String(json) == "D60")
    {
     digitalWrite(12, LOW);
    }

    if(String(json) == "D71")
    {
     digitalWrite(13, HIGH);
    }
    if(String(json) == "D70")
    {
     digitalWrite(13, LOW);
    }

    if(String(json) == "D81")
    {
     digitalWrite(15, HIGH);
    }
    if(String(json) == "D80")
    {
     digitalWrite(15, LOW);
    }

   
  free(json);
}

