#ifndef hitron_h
#define hitron_h
#include "communication.h"





//void pinset();
void setup_wifi();
void set_server();
void subs();
void pub();
void reconnect(); 
void readsensor();

#endif
