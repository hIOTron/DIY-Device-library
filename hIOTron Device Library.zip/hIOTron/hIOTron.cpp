#include "hIOTron.h"
//#include <util/delay.h>
//#include <Arduino.h>
//#include <hIOTron_MQTT.h>

byte server1[] = {52,66,59,180};
EthernetClient ethClient1;
void session(char* topic, byte* payload, unsigned int length); 

hIOTron_MQTT client1(server1, 1883, session, ethClient1);


void pinset();

//extern char* user;


void ServerConnect()
{
  if (!client1.connected())
  {
     if (client1.connect("Hitron"))
     {
       Serial.println("Connected with hIOTron Server");
	     extern char* user;
	     char* s1= user;
       strcat (s1,"/hiduino"); 
       Serial.println(user);
       
	   client1.subscribe(user);
     }
     }
	 pinset();
}


void Subscribe()
{
   Serial.println("Subscribed");
}


void infinite()
{
	
  client1.cont();
  delay(1000);
}

void give0(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p0";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
  
}
void give1(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p1";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give2(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p2";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give3(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p3";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give4(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p4";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give5(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p5";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give6(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p6";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give7(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p7";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give8(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p8";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give9(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p9";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}
void give10(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p10";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give11(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p11";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give12(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p12";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give13(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="p13";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give14(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="a0";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give15(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="a1";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give16(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="a2";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give17(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="a3";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}
void give18(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="a4";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}

void give19(const char* msd)
{
  extern char* user;
  String s2=user;
  s2.replace("/hiduino","/");
  String newu="a5";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  client1.publish(pubu,msd);
}



  						  