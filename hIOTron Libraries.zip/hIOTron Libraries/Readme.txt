Contents in hIOTron.rar	file:

1) hIOTron.zip :- Extract this file in C:\Users\%USERPROFILE%\Documents\Arduino\libraries
   		  Here replace %USERPROFILE% by the name of the user.
					
				OR

		Open Arduino and go to sketch option. Select 'include library' and opt for 'Add .zip library' option and browse for the file to select it.


2) libraries.exe :- Just run the exe file.