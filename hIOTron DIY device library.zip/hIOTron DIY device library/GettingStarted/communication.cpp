#include "communication.h"
#include <avr/io.h>
#include <Arduino.h>

void pinset()
{
  DDRD=0xFF;  //intialization port D as output
  DDRB=0xFF;   
  //Serial.println("set as a output");
}

