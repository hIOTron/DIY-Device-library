#include "reset.h"


 
 
void session(char* topic, byte* payload, unsigned int length)
{
  char* json;
  json = (char*) malloc(length + 1);
  memcpy(json, payload, length);
  json[length] = '\0';
 Serial.println(json);
  
 if (String(json)=="d01")
  {
      PORTD |= _BV(PORTD0);
    Serial.println("pin0 HIGH");
  }
  if(String(json)=="d00")
  {
      PORTD &= ~_BV(PORTD0);
    Serial.println("pin0 LOW");
  }  

  
  if (String(json)=="d11")
  {
      PORTD |= _BV(PORTD1);
    Serial.println("pin1 HIGH");
  }
  if(String(json)=="d10")
  {
      PORTD &= ~_BV(PORTD1);
    Serial.println("pin1 LOW");
  }
  
  if (String(json)=="d21")
  {
      PORTD |= _BV(PORTD2);
    Serial.println("pin2 HIGH");
  }
  if(String(json)=="d20")
  {
      PORTD &= ~_BV(PORTD2);
    Serial.println("pin2 LOW");
  }
  
  if (String(json)=="d31")
  {
      PORTD |= _BV(PORTD3);
    Serial.println("pin3 HIGH");
  }
  if(String(json)=="d30")
  {
      PORTD &= ~_BV(PORTD3);
    Serial.println("pin3 LOW");
  }
  
  if (String(json)=="d41")
  {
      PORTD |= _BV(PORTD4);
    Serial.println("pin4 HIGH");
  }
  if(String(json)=="d40")
  {
      PORTD &= ~_BV(PORTD4);
    Serial.println("pin4 LOW");
  }
  
  if (String(json)=="d51")
  {
      PORTD |= _BV(PORTD5);
    Serial.println("pin5 HIGH");
  }
  if(String(json)=="d50")
  {
    PORTD &= ~_BV(PORTD5);
    Serial.println("pin5 LOW");
  }
  
  if (String(json)=="d61")
  {
      PORTD |= _BV(PORTD6);
    Serial.println("pin6 HIGH");
  }
  if(String(json)=="d60")
  {
      PORTD &= ~_BV(PORTD6);
    Serial.println("pin6 LOW");
  }
  
  if (String(json)=="d71")
  {
      PORTD |= _BV(PORTD7);
    Serial.println("pin7 HIGH");
  }
  if(String(json)=="d70")
  {
      PORTD &= ~_BV(PORTD7);
    Serial.println("pin7 LOW");
  }
  
  if (String(json)=="d81")
  {
      PORTB |= _BV(PORTB0);
    Serial.println("pin8 HIGH");
  }
  if(String(json)=="d80")
  {
      PORTB &= ~_BV(PORTB0);
    Serial.println("pin8 LOW");
  }
  
  if (String(json)=="d91")
  {
      PORTB |= _BV(PORTB1);
    Serial.println("pin9 HIGH");
  }
  if(String(json)=="d90")
  {
      PORTB &= ~_BV(PORTB1);
  Serial.println("pin9 LOW");
  }
  
  if (String(json)=="d101")
  {
      PORTB |= _BV(PORTB2);
    Serial.println("pin10 HIGH");
  }
  if(String(json)=="d100")
  {
      PORTB &= ~_BV(PORTB2);
    Serial.println("pin10 LOW");
  }
  
  if (String(json)=="ch11")
  {
      PORTB |= _BV(PORTB3);
    Serial.println("pin11 HIGH");
  }
  if(String(json)=="bd11")
  {
      PORTB &= ~_BV(PORTB3);
    Serial.println("pin11 LOW");
  }
  
  if (String(json)=="ch12")
  {
      PORTB |= _BV(PORTB4);
    Serial.println("pin12 HIGH");
  }
  if(String(json)=="bd12")
  {
      PORTB &= ~_BV(PORTB4);
    Serial.println("pin12 LOW");
  }
  
  if (String(json)=="ch13")
  {
      PORTB |= _BV(PORTB5);
    Serial.println("pin13 HIGH");
  }
  if(String(json)=="bd13")
  {
      PORTB &= ~_BV(PORTB5);
    Serial.println("pin13 LOW");
  }
  
  free(json);
}
