#include "retain.h"
#include <Arduino.h>


 void Publish()
  {
    
  char buf[30];    
  int h0, h1, h2, h3, h4, h5, hd0, hd1, hd2, hd3, hd4, hd5, hd6, hd7, hd8, hd9, hd10, hd11, hd12, hd13;
  
  hd0=digitalRead(0);
  String l=String(hd0);  
  l.toCharArray(buf,30);
  give0(buf);
  //Serial.println("Sending Data");
  

  hd1=digitalRead(1);
  String m=String(hd1);  
  m.toCharArray(buf,30);
  give1(buf);

  hd2=digitalRead(2);
  String n=String(hd2);  
  n.toCharArray(buf,30);
  give2(buf);

  hd3=digitalRead(3);
  String o=String(hd3);  
  o.toCharArray(buf,30);
  give3(buf);

  hd4=digitalRead(4);
  String p=String(hd4);  
  p.toCharArray(buf,30);
  give4(buf);
  
  hd5=digitalRead(5);
  String a=String(hd5);  
  a.toCharArray(buf,30);
  give5(buf);
  
  hd6=digitalRead(6);
  String b=String(hd6);  
  b.toCharArray(buf,30);
  give6(buf);
  
  hd7=digitalRead(7);
  String c=String(hd7);  
  c.toCharArray(buf,30);
  give7(buf);
  
  hd8=digitalRead(8);
  String d=String(hd8);  
  d.toCharArray(buf,30);
  give8(buf);
  
  hd9=digitalRead(9);
  String e=String(hd9);  
  e.toCharArray(buf,30);
  give9(buf);
  
  hd10=digitalRead(10);
  String f=String(hd10);  
  f.toCharArray(buf,30);
  give10(buf);
  
  hd11=digitalRead(11);
  String g=String(hd11);  
  g.toCharArray(buf,30);
  give11(buf);
  
  hd12=digitalRead(12);
  String h=String(hd12);  
  h.toCharArray(buf,30);
  give12(buf);
  
  hd13=digitalRead(13);
  String i=String(hd13);  
  i.toCharArray(buf,30);
  give13(buf);

  h0=analogRead(A0);
  String q=String(h0);  
  q.toCharArray(buf,30);
  give14(buf);

  h1=analogRead(A1);
  String r=String(h1);  
  r.toCharArray(buf,30);
  give15(buf);

  h2=analogRead(A2);
  String s=String(h2);  
  s.toCharArray(buf,30);
  give16(buf);

  h3=analogRead(A3);
  String t=String(h3);  
  t.toCharArray(buf,30);
  give17(buf);

  h4=analogRead(A4);
  String u=String(h4);  
  u.toCharArray(buf,30);
  give18(buf);

  h5=analogRead(A5);
  String v=String(h5);  
  v.toCharArray(buf,30);
  give19(buf);
  
  }
  
