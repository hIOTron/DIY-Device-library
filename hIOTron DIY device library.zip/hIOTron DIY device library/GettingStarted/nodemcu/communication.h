#ifndef communication_h
#define communication_h

void pinset1();


#endif

