
#include "hitron.h"


#include <ESP8266WiFi.h>
#include <PubSubClient.h>
#include <WiFiClientSecure.h>


extern const char* ssid;
extern const char* password;

byte server[] = {52,66,59,180};

WiFiClient espClient;
PubSubClient client(espClient);

void callback(char* topic, byte* payload, unsigned int length);
void readsensor();
long lastMsg = 0;
char msg[50];
int value = 0;
int flag1=0;

//char* outTopic1  = "sensor";

char* inTopic1 = "led"; 

char* clientId  = "smart_node";





void setup_wifi() {

  delay(10);
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
  
}
void set_server()
{
  client.setServer(server, 1883);
  Serial.println("sever connected");
  
    
  
}

void subs()
{
  char buf[30];
  char buf1[30];
  char buf2[30];
  char buf3[30];
  char buf4[30];
  char buf5[30];
  char buf6[30];
  char buf7[30];
  char buf8[30];
  char buf9[30];
  char buf10[30];
  
  if (!client.connected()) {
    reconnect();
  }
  //datar();
 
 
   extern char* user;
   String s2=user;
   //s2.replace("/nodemcu","/");
   String newu="/a0";
   String neww=s2+newu; 
   char pubu[50];
   int x=analogRead(A0);
   String k=String(x);
   k.toCharArray(buf,30);
   neww.toCharArray(pubu,70);
   client.publish(pubu,buf);
  
  //client.publish("A0",buf);
   Serial.println(pubu);

   int x1=digitalRead(16);
   String k1=String(x1);
   k1.toCharArray(buf1,30);
   String newu1="/d0";
   String neww1=s2+newu1; 
   char pubu1[50];
   neww1.toCharArray(pubu1,70);
   client.publish(pubu1,buf1);
  
  // client.publish("D0",buf1);
  
   Serial.println(pubu1);

   int x2=digitalRead(5);
   String k2=String(x2);
   k2.toCharArray(buf2,30);
   String newu2="/d1";
   String neww2=s2+newu2; 
   char pubu2[50];
   neww2.toCharArray(pubu2,70);
   client.publish(pubu2,buf2);
  // client.publish("D1",buf2);
   Serial.println(pubu2);

   int x3=digitalRead(4);
   String k3=String(x3);
   k3.toCharArray(buf3,30);
   String newu3="/d2";
   String neww3=s2+newu3; 
   char pubu3[50];
   neww3.toCharArray(pubu3,70);
   client.publish(pubu3,buf3);
  // client.publish("D1",buf2);
   Serial.println(pubu3);

   //client.publish("D2",buf3);
   //Serial.println(x3);

   int x4=digitalRead(0);
   String k4=String(x4);
   k4.toCharArray(buf4,30);
   String newu4="/d3";
   String neww4=s2+newu4; 
   char pubu4[50];
   neww4.toCharArray(pubu4,70);
   client.publish(pubu4,buf4);
  // client.publish("D1",buf2);
   Serial.println(pubu4);
   
   //client.publish("D3",buf4);
  // Serial.println(x4);

   int x5=digitalRead(2);
   String k5=String(x5);
   k5.toCharArray(buf5,30);
   String newu5="/d4";
   String neww5=s2+newu5; 
   char pubu5[50];
   neww5.toCharArray(pubu5,70);
   client.publish(pubu5,buf5);
  // client.publish("D1",buf2);
   Serial.println(pubu5);
   //client.publish("D4",buf5);
   //Serial.println(x5);

   int x6=digitalRead(14);
   String k6=String(x6);
   k6.toCharArray(buf6,30);
  //client.publish("D5",buf6);
   String newu6="/d5";
   String neww6=s2+newu6; 
   char pubu6[50];
   neww6.toCharArray(pubu6,70);
   client.publish(pubu6,buf6);
 // client.publish("D1",buf2);
   Serial.println(pubu6);
  // Serial.println(x6);


   int x7=digitalRead(12);
   String k7=String(x7);
   k7.toCharArray(buf7,30);
   //client.publish("D6",buf7);
   

   int x8=digitalRead(13);
   String k8=String(x8);
   k8.toCharArray(buf8,30);
   String newu8="/d7";
   String neww8=s2+newu8; 
   char pubu8[50];
   neww8.toCharArray(pubu8,70);
   client.publish(pubu8,buf8);
   Serial.println(pubu8);
   //client.publish("D7",buf8);
   

   int x9=digitalRead(15);
   String k9=String(x9);
   k9.toCharArray(buf9,30);
   String newu9="/d8";
   String neww9=s2+newu9; 
   char pubu9[50];
   neww9.toCharArray(pubu9,70);
   client.publish(pubu9,buf9);
   Serial.println(pubu9);
   //client.publish("D8",buf9);
 
  client.loop();
delay(500); 
}


void pub()
{
client.setCallback(callback);
}



void reconnect()
{
    extern char* inTopic1; 
    Serial.print("Attempting MQTT connection...");
    if (client.connect("smart_robo")) {
      Serial.println("connected");
      extern char* user;
     char* s1= user;
       strcat (s1,"/nodemcu"); 
       Serial.println(user);
      client.subscribe(user);
      //client.subscribe(inTopic1);
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      delay(5000);
    }
    
}


