

#include <ESP8266WiFi.h>
#include <PubSubClient.h>
//#include <WiFiClientSecure.h>




void callback(char* topic, byte* payload, unsigned int length)
{
  char* json;
  int i;
  json = (char*) malloc(length + 1);
  memcpy(json, payload, length);
  json[length] = '\0';
  
  if(String(json) == "d01")
    {
     digitalWrite(16, HIGH);
    }
    if(String(json) == "d00")
    {
     digitalWrite(16, LOW);
    }
    
    if(String(json) == "d11")
    {
     digitalWrite(5, HIGH);
    }
    if(String(json) == "d10")
    {
     digitalWrite(5, LOW);
    }

    if(String(json) == "d21")
    {
     digitalWrite(4, HIGH);
    }
    if(String(json) == "d20")
    {
     digitalWrite(4, LOW);
    }

    
    if(String(json) == "d31")
    {
     digitalWrite(0, HIGH);
    }
    if(String(json) == "d30")
    {
     digitalWrite(0, LOW);
    }
    
    if(String(json) == "d41")
    {
     digitalWrite(2, HIGH);
    }
    if(String(json) == "d40")
    {
     digitalWrite(2, LOW);
    }

    
    if(String(json) == "d51")
    {
     digitalWrite(14, HIGH);
    }
    if(String(json) == "d50")
    {
     digitalWrite(14, LOW);
    }

    if(String(json) == "d61")
    {
     digitalWrite(12, HIGH);
    }
    if(String(json) == "d60")
    {
     digitalWrite(12, LOW);
    }

    if(String(json) == "d71")
    {
     digitalWrite(13, HIGH);
    }
    if(String(json) == "d70")
    {
     digitalWrite(13, LOW);
    }

    if(String(json) == "d81")
    {
     digitalWrite(15, HIGH);
    }
    if(String(json) == "d80")
    {
     digitalWrite(15, LOW);
    }

   
  free(json);
}

