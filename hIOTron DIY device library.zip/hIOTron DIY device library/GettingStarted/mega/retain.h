#ifndef retain_h
#define retain_h



void Publish();
void give0(const char* msd);
void give1(const char* msd);
void give2(const char* msd);
void give3(const char* msd);
void give4(const char* msd);
void give5(const char* msd);
void give6(const char* msd);
void give7(const char* msd);
void give8(const char* msd);
void give9(const char* msd);
void give10(const char* msd);
void give11(const char* msd);
void give12(const char* msd);
void give13(const char* msd);
void give14(const char* msd);
void give15(const char* msd);
void give16(const char* msd);
void give17(const char* msd);
void give18(const char* msd);
void give19(const char* msd);
void give20(const char* msd);
void give21(const char* msd);
void give22(const char* msd);
void give23(const char* msd);
void give24(const char* msd);
void give25(const char* msd);
void give26(const char* msd);
void give27(const char* msd);
void give28(const char* msd);
void give29(const char* msd);
void give30(const char* msd);
void give31(const char* msd);
void give32(const char* msd);
void give33(const char* msd);
void give34(const char* msd);
void give35(const char* msd);
void give36(const char* msd);
void give37(const char* msd);
void give38(const char* msd);
void give39(const char* msd);
void give40(const char* msd);
void give41(const char* msd);
void give42(const char* msd);
void give43(const char* msd);
void give44(const char* msd);
void give45(const char* msd);
void give46(const char* msd);
void give47(const char* msd);
void give48(const char* msd);
void give49(const char* msd);
void give50(const char* msd);
void give51(const char* msd);
void give52(const char* msd);
void give53(const char* msd);
void give54(const char* msd);
void give55(const char* msd);
void give56(const char* msd);
void give57(const char* msd);
void give58(const char* msd);
void give59(const char* msd);
void give60(const char* msd);
void give61(const char* msd);
void give62(const char* msd);
void give63(const char* msd);
void give64(const char* msd);
void give65(const char* msd);

#endif
