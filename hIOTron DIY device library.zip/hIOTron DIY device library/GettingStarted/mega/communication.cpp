#include "communication.h"
#include <avr/io.h>
#include "Arduino.h"

void pinset()
{
  DDRA=0xFF;  //intialization port D as output
  DDRB=0xFF; 
  DDRC=0xFF; 
  DDRD=0xFF;
  DDRE=0xFF;
  DDRG=0xFF;
  DDRH=0xFF;
  DDRJ=0xFF;
  DDRL=0xFF;
  Serial.println("set as a output");
}

