#include "reset.h"


 
void session(char* topic, byte* payload, unsigned int length)
{
  char* json;
  json = (char*) malloc(length + 1);
  memcpy(json, payload, length);
  json[length] = '\0';
 
  
if (String(json)=="d01")
  {
      PORTD |= _BV(PORTE0);
    Serial.println("pin0 HIGH");
  }
  if(String(json)=="d00")
  {
      PORTD &= ~_BV(PORTE0);
    Serial.println("pin0 LOW");
  }  

  
if (String(json)=="d11")
  {
      PORTE |= _BV(PORTE1);
    Serial.println("pin1 HIGH");
  }
  if(String(json)=="d10")
  {
      PORTE &= ~_BV(PORTE1);
    Serial.println("pin1 LOW");
  }
  
  if (String(json)=="d21")
  {
      PORTE |= _BV(PORTE4);
    Serial.println("pin2 HIGH");
  }
  if(String(json)=="d20")
  {
      PORTE &= ~_BV(PORTE4);
    Serial.println("pin2 LOW");
  }
  
  if (String(json)=="d31")
  {
      PORTE |= _BV(PORTE5);
    Serial.println("pin3 HIGH");
  }
  if(String(json)=="d30")
  {
      PORTE &= ~_BV(PORTE5);
    Serial.println("pin3 LOW");
  }
  
  if (String(json)=="d41")
  {
      PORTG |= _BV(PORTG5);
    Serial.println("pin4 HIGH");
  }
  if(String(json)=="d40")
  {
      PORTG &= ~_BV(PORTG5);
    Serial.println("pin4 LOW");
  }
  
  if (String(json)=="d51")
  {
      PORTE |= _BV(PORTE3);
    Serial.println("pin5 HIGH");
  }
  if(String(json)=="d50")
  {
      PORTE &= ~_BV(PORTE3);
    Serial.println("pin5 LOW");
  }
  
  if (String(json)=="d61")
  {
      PORTH |= _BV(PORTH3);
    Serial.println("pin6 HIGH");
  }
  if(String(json)=="d60")
  {
      PORTH &= ~_BV(PORTH3);
    Serial.println("pin6 LOW");
  }
  
  if (String(json)=="d71")
  {
      PORTH |= _BV(PORTH4);
    Serial.println("pin7 HIGH");
  }
  if(String(json)=="d70")
  {
      PORTH &= ~_BV(PORTH4);
    Serial.println("pin7 LOW");
  }
  
  if (String(json)=="d81")
  {
      PORTH |= _BV(PORTH5);
    Serial.println("pin8 HIGH");
  }
  if(String(json)=="d80")
  {
      PORTH &= ~_BV(PORTH5);
    Serial.println("pin8 LOW");
  }
  
  if (String(json)=="d91")
  {
      PORTH |= _BV(PORTH6);
    Serial.println("pin9 HIGH");
  }
  if(String(json)=="d90")
  {
      PORTH &= ~_BV(PORTH6);
  Serial.println("pin9 LOW");
  }
  
  if (String(json)=="d101")
  {
      PORTB |= _BV(PORTB4);
    Serial.println("pin10 HIGH");
  }
  if(String(json)=="d100")
  {
      PORTB &= ~_BV(PORTB4);
    Serial.println("pin10 LOW");
  }
  
  if (String(json)=="d111")
  {
      PORTB |= _BV(PORTB5);
    Serial.println("pin11 HIGH");
  }
  if(String(json)=="d110")
  {
      PORTB &= ~_BV(PORTB5);
    Serial.println("pin11 LOW");
  }
  
  if (String(json)=="d121")
  {
      PORTB |= _BV(PORTB6);
    Serial.println("pin12 HIGH");
  }
  if(String(json)=="d120")
  {
      PORTB &= ~_BV(PORTB6);
    Serial.println("pin12 LOW");
  }
  
  if (String(json)=="d131")
  {
      PORTB |= _BV(PORTB7);
    Serial.println("pin13 HIGH");
  }
  if(String(json)=="d130")
  {
      PORTB &= ~_BV(PORTB7);
    Serial.println("pin13 LOW");
  }

  if (String(json)=="d141")
  {
      PORTJ |= _BV(PORTJ1);
    Serial.println("pin14 HIGH");
  }
  if(String(json)=="d140")
  {
      PORTJ &= ~_BV(PORTJ1);
    Serial.println("pin14 LOW");
  }

  if (String(json)=="d151")
  {
      PORTJ |= _BV(PORTJ0);
    Serial.println("pin15 HIGH");
  }
  if(String(json)=="d150")
  {
      PORTJ &= ~_BV(PORTJ0);
    Serial.println("pin15 LOW");
  }

  if (String(json)=="d161")
  {
      PORTH |= _BV(PORTH1);
    Serial.println("pin16 HIGH");
  }
  if(String(json)=="d160")
  {
      PORTH &= ~_BV(PORTH1);
    Serial.println("pin16 LOW");
  }

  if (String(json)=="d171")
  {
      PORTH |= _BV(PORTH0);
    Serial.println("pin17 HIGH");
  }
  if(String(json)=="d170")
  {
      PORTH &= ~_BV(PORTH0);
    Serial.println("pin17 LOW");
  }

  if (String(json)=="d181")
  {
      PORTD |= _BV(PORTD3);
    Serial.println("pin18 HIGH");
  }
  if(String(json)=="d180")
  {
      PORTD &= ~_BV(PORTD3);
    Serial.println("pin18 LOW");
  }

  if (String(json)=="d191")
  {
      PORTD |= _BV(PORTD2);
    Serial.println("pin19 HIGH");
  }
  if(String(json)=="d190")
  {
      PORTD &= ~_BV(PORTD2);
    Serial.println("pin19 LOW");
  }

  if (String(json)=="d201")
  {
      PORTD |= _BV(PORTD1);
    Serial.println("pin20 HIGH");
  }
  if(String(json)=="d200")
  {
      PORTD &= ~_BV(PORTD1);
    Serial.println("pin20 LOW");
  }

  if (String(json)=="d211")
  {
      PORTD |= _BV(PORTD0);
    Serial.println("pin21 HIGH");
  }
  if(String(json)=="d210")
  {
      PORTD &= ~_BV(PORTD0);
    Serial.println("pin21 LOW");
  }

 if (String(json)=="d221")
  {
      PORTA |= _BV(PORTA0);
    Serial.println("pin22 HIGH");
  }
  if(String(json)=="d220")
  {
      PORTA &= ~_BV(PORTA0);
    Serial.println("pin22 LOW");
  }

  if (String(json)=="d231")
  {
      PORTA |= _BV(PORTA1);
    Serial.println("pin23 HIGH");
  }
  if(String(json)=="d230")
  {
      PORTA &= ~_BV(PORTA1);
    Serial.println("pin23 LOW");

  }

  if (String(json)=="d241")
  {
      PORTA |= _BV(PORTA2);
    Serial.println("pin24 HIGH");
  }
  if(String(json)=="d240")
  {
      PORTA &= ~_BV(PORTA2);
    Serial.println("pin24 LOW");

  }

  if (String(json)=="d251")
  {
      PORTA |= _BV(PORTA3);
    Serial.println("pin25 HIGH");
  }
  if(String(json)=="d250")
  {
      PORTA &= ~_BV(PORTA3);
    Serial.println("pin25 LOW");

  }

  if (String(json)=="d261")
  {
      PORTA |= _BV(PORTA4);
    Serial.println("pin26 HIGH");
  }
  if(String(json)=="d260")
  {
      PORTA &= ~_BV(PORTA4);
    Serial.println("pin26 LOW");

  }

  if (String(json)=="d271")
  {
      PORTA |= _BV(PORTA5);
    Serial.println("pin27 HIGH");
  }
  if(String(json)=="d270")
  {
      PORTA &= ~_BV(PORTA5);
    Serial.println("pin27 LOW");

  }

  if (String(json)=="d281")
  {
      PORTA |= _BV(PORTA6);
    Serial.println("pin28 HIGH");
  }
  if(String(json)=="d280")
  {
      PORTA &= ~_BV(PORTA6);
    Serial.println("pin28 LOW");

  }

  if (String(json)=="d291")
  {
      PORTA |= _BV(PORTA7);
    Serial.println("pin29 HIGH");
  }
  if(String(json)=="d290")
  {
      PORTA &= ~_BV(PORTA7);
    Serial.println("pin29 LOW");

  }

  if (String(json)=="d301")
  {
      PORTC |= _BV(PORTC7);
    Serial.println("pin30 HIGH");
  }
  if(String(json)=="d300")
  {
      PORTC &= ~_BV(PORTC7);
    Serial.println("pin30 LOW");

  }

  if (String(json)=="d311")
  {
      PORTC |= _BV(PORTC6);
    Serial.println("pin31 HIGH");
  }
  if(String(json)=="d310")
  {
      PORTC &= ~_BV(PORTC6);
    Serial.println("pin31 LOW");

  }

  if (String(json)=="d321")
  {
      PORTC |= _BV(PORTC5);
    Serial.println("pin32 HIGH");
  }
  if(String(json)=="d320")
  {
      PORTC &= ~_BV(PORTC5);
    Serial.println("pin32 LOW");

  }

  if (String(json)=="d331")
  {
      PORTC |= _BV(PORTC4);
    Serial.println("pin33 HIGH");
  }
  if(String(json)=="d330")
  {
      PORTC &= ~_BV(PORTC4);
    Serial.println("pin33 LOW");

  }

  if (String(json)=="d341")
  {
      PORTC |= _BV(PORTC3);
    Serial.println("pin34 HIGH");
  }
  if(String(json)=="d340")
  {
      PORTC &= ~_BV(PORTC3);
    Serial.println("pin34 LOW");

  }

  if (String(json)=="d351")
  {
      PORTC |= _BV(PORTC2);
    Serial.println("pin35 HIGH");
  }
  if(String(json)=="d350")
  {
      PORTC &= ~_BV(PORTC2);
    Serial.println("pin35 LOW");

  }

  if (String(json)=="d361")
  {
      PORTC |= _BV(PORTC1);
    Serial.println("pin36 HIGH");
  }
  if(String(json)=="d360")
  {
      PORTC &= ~_BV(PORTC1);
    Serial.println("pin36 LOW");

  }

  if (String(json)=="d371")
  {
      PORTC |= _BV(PORTC0);
    Serial.println("pin37 HIGH");
  }
  if(String(json)=="d370")
  {
      PORTC &= ~_BV(PORTC0);
    Serial.println("pin37 LOW");

  }

  if (String(json)=="d381")
  {
      PORTD |= _BV(PORTD7);
    Serial.println("pin38 HIGH");
  }
  if(String(json)=="d380")
  {
      PORTD &= ~_BV(PORTD7);
    Serial.println("pin38 LOW");

  }

  if (String(json)=="d391")
  {
      PORTG |= _BV(PORTG2);
    Serial.println("pin39 HIGH");
  }
  if(String(json)=="d390")
  {
      PORTG &= ~_BV(PORTG2);
    Serial.println("pin39 LOW");

  }

  if (String(json)=="d401")
  {
      PORTG |= _BV(PORTG1);
    Serial.println("pin40 HIGH");
  }
  if(String(json)=="d400")
  {
      PORTG &= ~_BV(PORTG1);
    Serial.println("pin40 LOW");

  }

  if (String(json)=="d411")
  {
      PORTG |= _BV(PORTG0);
    Serial.println("pin41 HIGH");
  }
  if(String(json)=="d410")
  {
      PORTG &= ~_BV(PORTG0);
    Serial.println("pin41 LOW");

  }

  if (String(json)=="d421")
  {
      PORTL |= _BV(PORTL7);
    Serial.println("pin42 HIGH");
  }
  if(String(json)=="d420")
  {
      PORTL &= ~_BV(PORTL7);
    Serial.println("pin42 LOW");

  }

  if (String(json)=="d431")
  {
      PORTL |= _BV(PORTL6);
    Serial.println("pin43 HIGH");
  }
  if(String(json)=="d430")
  {
      PORTL &= ~_BV(PORTL6);
    Serial.println("pin43 LOW");

  }

  if (String(json)=="d441")
  {
      PORTL |= _BV(PORTL5);
    Serial.println("pin44 HIGH");
  }
  if(String(json)=="d440")
  {
      PORTL &= ~_BV(PORTL5);
    Serial.println("pin44 LOW");

  }

  if (String(json)=="d451")
  {
      PORTL |= _BV(PORTL4);
    Serial.println("pin45 HIGH");
  }
  if(String(json)=="d450")
  {
      PORTL &= ~_BV(PORTL4);
    Serial.println("pin45 LOW");

  }

  if (String(json)=="d461")
  {
      PORTL |= _BV(PORTL3);
    Serial.println("pin46 HIGH");
  }
  if(String(json)=="d460")
  {
      PORTL &= ~_BV(PORTL3);
    Serial.println("pin46 LOW");

  }

  if (String(json)=="d471")
  {
      PORTL |= _BV(PORTL2);
    Serial.println("pin47 HIGH");
  }
  if(String(json)=="d470")
  {
      PORTL &= ~_BV(PORTL2);
    Serial.println("pin47 LOW");

  }

  if (String(json)=="d481")
  {
      PORTL |= _BV(PORTL1);
    Serial.println("pin48 HIGH");
  }
  if(String(json)=="d480")
  {
      PORTL &= ~_BV(PORTL1);
    Serial.println("pin48 LOW");

  }

  if (String(json)=="d491")
  {
      PORTL |= _BV(PORTL0);
    Serial.println("pin49 HIGH");
  }
  if(String(json)=="d490")
  {
      PORTL &= ~_BV(PORTL0);
    Serial.println("pin49 LOW");

  }

  if (String(json)=="d50")
  {
      PORTB |= _BV(PORTB3);
    Serial.println("pin50 HIGH");
  }
  if(String(json)=="d50")
  {
      PORTB &= ~_BV(PORTB3);
    Serial.println("pin50 LOW");

  }

  if (String(json)=="d51")
  {
      PORTB |= _BV(PORTB2);
    Serial.println("pin51 HIGH");
  }
  if(String(json)=="d51")
  {
      PORTB &= ~_BV(PORTB2);
    Serial.println("pin51 LOW");

  }

  if (String(json)=="d52")
  {
      PORTB |= _BV(PORTB1);
    Serial.println("pin52 HIGH");
  }
  if(String(json)=="d52")
  {
      PORTB &= ~_BV(PORTB1);
    Serial.println("pin52 LOW");

  }

  if (String(json)=="d53")
  {
      PORTB |= _BV(PORTB0);
    Serial.println("pin53 HIGH");
  }
  if(String(json)=="d53")
  {
      PORTB &= ~_BV(PORTB0);
    Serial.println("pin53 LOW");

  }

  
  free(json);
}
