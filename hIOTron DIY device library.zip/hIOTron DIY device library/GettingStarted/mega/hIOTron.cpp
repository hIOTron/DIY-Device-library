#include "hIOTron.h"
//#include <util/delay.h>
//#include <Arduino.h>
//#include <hIOTron_MQTT.h>

byte server1[] = {54,238,179,124};
EthernetClient ethClient1;
void session(char* topic, byte* payload, unsigned int length); 

hIOTron_MQTT client1(server1, 1883, session, ethClient1);


void pinset();

//extern char* user;


void ServerConnect()
{
  if (!client1.connected())
  {
     if (client1.connect("Hitron"))
     {
     Serial.println("Connected with hIOTron Server");
     extern char* user;
     char* s1= user;
     strcat(s1,"/Arduinomega"); 
     client1.subscribe(user);
     Serial.println(user);
     
     }
     }
   pinset();
}


void Subscribe()
{
   Serial.println("Subscribed");
}


void infinite()
{
  
  client1.cont();
  delay(1000);
}

void give0(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d0";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
  
}
void give1(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d1";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give2(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d2";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give3(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d3";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give4(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d4";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give5(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d5";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give6(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d6";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}
void give7(const char* msd)
{
 extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d7";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give8(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d8";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give9(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d9";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}
void give10(const char* msd)
{
//  extern char* user;
//  String s2=user;
//  //s2.replace("/hiduino","/");
//  String newu="/d10";
//  String neww=s2+newu; 
//  char pubu[50];
//  neww.toCharArray(pubu,70);
//  //Serial.println(pubu);
//  client1.publish(pubu,msd);
}

void give11(const char* msd)
{
//  extern char* user;
//  String s2=user;
//  //s2.replace("/hiduino","/");
//  String newu="/d11";
//  String neww=s2+newu; 
//  char pubu[50];
//  neww.toCharArray(pubu,70);
//  //Serial.println(pubu);
//  client1.publish(pubu,msd);
}

void give12(const char* msd)
{
//  extern char* user;
//  String s2=user;
//  //s2.replace("/hiduino","/");
//  String newu="/d12";
//  String neww=s2+newu; 
//  char pubu[50];
//  neww.toCharArray(pubu,70);
//  //Serial.println(pubu);
//  client1.publish(pubu,msd);
}
void give13(const char* msd)
{
//  extern char* user;
//  String s2=user;
//  //s2.replace("/hiduino","/");
//  String newu="/d13";
//  String neww=s2+newu; 
//  char pubu[50];
//  neww.toCharArray(pubu,70);
//  //Serial.println(pubu);
//  client1.publish(pubu,msd);
}

void give14(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a0";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give15(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a1";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give16(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a2";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give17(const char* msd)
{
  extern char* user;
  String s2=user;
  String newu="/a3";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}
void give18(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a4";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give19(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a5";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give20(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a6";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give21(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a7";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give22(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a8";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give23(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a9";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give24(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a10";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give25(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a11";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);

}
void give26(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a12";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give27(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a13";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give28(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a14";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give29(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/a15";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give30(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d14";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give31(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d15";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give32(const char* msd)
{

  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d16";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give33(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d17";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give34(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d18";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give35(const char* msd)
{ 
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d19";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give36(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d20";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give37(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d21";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give38(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d22";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give39(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d23";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give40(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d24";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give41(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d25";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give42(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d26";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give43(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d27";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give44(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d28";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}



void give45(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d29";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give46(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d30";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give47(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d31";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give48(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d32";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give49(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d33";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give50(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d34";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give51(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d35";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give52(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d36";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give53(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d37";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
 
}


void give54(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d38";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give55(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d39";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give56(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d40";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


void give57(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d41";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give58(const char* msd)
{ 
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d42";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give59(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d43";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give60(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d44";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}
void give61(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d45";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
  
}

void give62(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d46";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give63(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d47";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}

void give64(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d48";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
  
}

void give65(const char* msd)
{
  extern char* user;
  String s2=user;
  //s2.replace("/hiduino","/");
  String newu="/d49";
  String neww=s2+newu; 
  char pubu[50];
  neww.toCharArray(pubu,70);
  //Serial.println(pubu);
  client1.publish(pubu,msd);
}


              
                
