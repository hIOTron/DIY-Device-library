#include "retain.h"
#include "Arduino.h"


 void Publish()
  {
    
  char buf[30];    
  int h0, h1, h2, h3, h4, h5, hd0, hd1, hd2, hd3, hd4, hd5, hd6, hd7, hd8, hd9, hd10, hd11, hd12, hd13;
  int hd14, hd15, hd16, hd17, hd18, hd19, hd20, hd21, hd22, hd23, hd24, hd25, hd26, hd27,hd28,hd29,hd30,hd31,hd32,hd33,hd34;
  int hd35,hd36,hd37,hd38,hd39,hd40,hd41,hd42,hd43,hd44,hd45,hd46,hd47,hd48,hd49,hd50,hd51,hd52,hd53;
  int h6,h7,h8,h9,h10,h11,h12,h13,h14,h15;
  
  hd0=digitalRead(0);
  String l=String(hd0);  
  l.toCharArray(buf,30);
  give0(buf);
  //Serial.println("Sending Data");
  

  hd1=digitalRead(1);
  String m=String(hd1);  
  m.toCharArray(buf,30);
  give1(buf);

  hd2=digitalRead(2);
  String n=String(hd2);  
  n.toCharArray(buf,30);
  give2(buf);

  hd3=digitalRead(3);
  String o=String(hd3);  
  o.toCharArray(buf,30);
  give3(buf);

  hd4=digitalRead(4);
  String p=String(hd4);  
  p.toCharArray(buf,30);
  give4(buf);
  
  hd5=digitalRead(5);
  String a=String(hd5);  
  a.toCharArray(buf,30);
  give5(buf);
  
  hd6=digitalRead(6);
  String b=String(hd6);  
  b.toCharArray(buf,30);
  give6(buf);
  
  hd7=digitalRead(7);
  String c=String(hd7);  
  c.toCharArray(buf,30);
  give7(buf);
  
  hd8=digitalRead(8);
  String d=String(hd8);  
  d.toCharArray(buf,30);
  give8(buf);
  
  hd9=digitalRead(9);
  String e=String(hd9);  
  e.toCharArray(buf,30);
  give9(buf);
  
  hd10=digitalRead(10);
  String f=String(hd10);  
  f.toCharArray(buf,30);
  give10(buf);
  
  hd11=digitalRead(11);
  String g=String(hd11);  
  g.toCharArray(buf,30);
  give11(buf);
  
  hd12=digitalRead(12);
  String h=String(hd12);  
  h.toCharArray(buf,30);
  give12(buf);
  
  hd13=digitalRead(13);
  String i=String(hd13);  
  i.toCharArray(buf,30);
  give13(buf);

  
  
  h0=analogRead(A0);
  String q=String(h0);  
  q.toCharArray(buf,30);
  give14(buf);

  h1=analogRead(A1);
  String r=String(h1);  
  r.toCharArray(buf,30);
  give15(buf);

  h2=analogRead(A2);
  String s=String(h2);  
  s.toCharArray(buf,30);
  give16(buf);

  h3=analogRead(A3);
  String t=String(h3);  
  t.toCharArray(buf,30);
  give17(buf);

  h4=analogRead(A4);
  String u=String(h4);  
  u.toCharArray(buf,30);
  give18(buf);

  h5=analogRead(A5);
  String v=String(h5);  
  v.toCharArray(buf,30);
  give19(buf);

  h6=analogRead(A6);
  String v1=String(h6);  
  v1.toCharArray(buf,30);
  give20(buf);

  h7=analogRead(A7);
  String v2=String(h7);  
  v2.toCharArray(buf,30);
  give21(buf);

  h8=analogRead(A8);
  String v3=String(h8);  
  v3.toCharArray(buf,30);
  give22(buf);

  h9=analogRead(A9);
  String v4=String(h9);  
  v4.toCharArray(buf,30);
  give23(buf);

  h10=analogRead(A10);
  String v5=String(h10);  
  v5.toCharArray(buf,30);
  give24(buf);

  h11=analogRead(A11);
  String v6=String(h11);  
  v6.toCharArray(buf,30);
  give25(buf);

  h12=analogRead(A12);
  String v7=String(h12);  
  v7.toCharArray(buf,30);
  give26(buf);

  h13=analogRead(A13);
  String v8=String(h13);  
  v8.toCharArray(buf,30);
  give27(buf);

  h14=analogRead(A14);
  String v9=String(h14);  
  v9.toCharArray(buf,30);
  give28(buf);

  h15=analogRead(A15);
  String v10=String(h15);  
  v10.toCharArray(buf,30);
  give29(buf);

  hd14=digitalRead(14);
  String d14=String(hd14);  
  d14.toCharArray(buf,30);
  give30(buf);

  hd15=digitalRead(15);
  String d15=String(hd15);  
  d15.toCharArray(buf,30);
  give31(buf);

  hd16=digitalRead(16);
  String d16=String(hd16);  
  d16.toCharArray(buf,30);
  give32(buf);

  hd17=digitalRead(17);
  String d17=String(hd17);  
  d17.toCharArray(buf,30);
  give33(buf);

  hd18=digitalRead(18);
  String d18=String(hd18);  
  d18.toCharArray(buf,30);
  give34(buf);

  hd19=digitalRead(19);
  String d19=String(hd19);  
  d19.toCharArray(buf,30);
  give35(buf);

  hd20=digitalRead(20);
  String d20=String(hd20);  
  d20.toCharArray(buf,30);
  give36(buf);

  hd21=digitalRead(21);
  String d21=String(hd21);  
  d21.toCharArray(buf,30);
  give37(buf);

  hd22=digitalRead(22);
  String d22=String(hd22);  
  d22.toCharArray(buf,30);
  give38(buf);

  hd23=digitalRead(23);
  String d23=String(hd23);  
  d23.toCharArray(buf,30);
  give39(buf);

  hd24=digitalRead(24);
  String d24=String(hd24);  
  d24.toCharArray(buf,30);
  give40(buf);

  hd25=digitalRead(25);
  String d25=String(hd25);  
  d25.toCharArray(buf,30);
  give41(buf);

  hd26=digitalRead(26);
  String d26=String(hd26);  
  d26.toCharArray(buf,30);
  give42(buf);

  hd27=digitalRead(27);
  String d27=String(hd27);  
  d27.toCharArray(buf,30);
  give43(buf);

  hd28=digitalRead(28);
  String d28=String(hd28);  
  d28.toCharArray(buf,30);
  give44(buf);

  hd29=digitalRead(29);
  String d29=String(hd29);  
  d29.toCharArray(buf,30);
  give45(buf);

  hd30=digitalRead(30);
  String d30=String(hd30);  
  d30.toCharArray(buf,30);
  give46(buf);

  hd31=digitalRead(31);
  String d31=String(hd31);  
  d31.toCharArray(buf,30);
  give47(buf);

  hd32=digitalRead(32);
  String d32=String(hd32);  
  d32.toCharArray(buf,32);
  give48(buf); 

  hd33=digitalRead(33);
  String d33=String(hd33);  
  d33.toCharArray(buf,30);
  give49(buf);

  hd34=digitalRead(34);
  String d34=String(hd34);  
  d34.toCharArray(buf,30);
  give50(buf);

  hd35=digitalRead(35);
  String d35=String(hd35);  
  d35.toCharArray(buf,30);
  give51(buf);

  hd36=digitalRead(36);
  String d36=String(hd36);  
  d36.toCharArray(buf,30);
  give52(buf);

  hd37=digitalRead(37);
  String d37=String(hd37);  
  d37.toCharArray(buf,30);
  give53(buf);

  
  hd38=digitalRead(38);
  String d38=String(hd38);  
  d38.toCharArray(buf,30);
  give54(buf);

  hd39=digitalRead(39);
  String d39=String(hd39);  
  d39.toCharArray(buf,30);
  give55(buf);

  hd40=digitalRead(40);
  String d40=String(hd40);  
  d40.toCharArray(buf,30);
  give56(buf);

  hd41=digitalRead(41);
  String d41=String(hd41);  
  d41.toCharArray(buf,30);
  give57(buf);

  hd42=digitalRead(42);
  String d42=String(hd42);  
  d42.toCharArray(buf,30);
  give58(buf);

  hd43=digitalRead(43);
  String d43=String(hd43);  
  d43.toCharArray(buf,30);
  give59(buf);

  hd44=digitalRead(44);
  String d44=String(hd44);  
  d44.toCharArray(buf,30);
  give60(buf);
  
  hd45=digitalRead(45);
  String d45=String(hd45);  
  d45.toCharArray(buf,30);
  give61(buf);

  hd46=digitalRead(46);
  String d46=String(hd46);  
  d46.toCharArray(buf,30);
  give62(buf);

  hd47=digitalRead(47);
  String d47=String(hd47);  
  d47.toCharArray(buf,30);
  give63(buf);

  hd48=digitalRead(48);
  String d48=String(hd48);  
  d48.toCharArray(buf,30);
  give64(buf);

  hd49=digitalRead(49);
  String d49=String(hd49);  
  d49.toCharArray(buf,30);
  give65(buf);

  
  }
  
